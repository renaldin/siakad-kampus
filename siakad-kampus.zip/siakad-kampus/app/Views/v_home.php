<div class="row">
    <div class="col-sm-12">
        <div class="text-center">
            <h1><b>Sistem Informasi Akademik Kampus</b></h1>
        </div>    
    </div><center>
    <div class="col-sm-12">
        <img class="img-responsive pad" width="70%" src="<?= base_url()?>/gambar/akademika.png" alt="Photo">
    </div></center>
</div>